from django.apps import AppConfig


class EmparpPanelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'emparp_panel'
