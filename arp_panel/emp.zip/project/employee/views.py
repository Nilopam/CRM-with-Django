import http
import random
import string
from urllib import request
from django.shortcuts import redirect, render
from django.http import HttpResponse
from .models import *
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from admin_panel.models import *
from .forms import *
# Create your views here.



# employee crud views starts
def create_emp(request):
    if request.method == "POST":
        data = request.POST
        name = data['name']
        address = data['address']
        dob = data['dob']
        # empCode = data['empCode']
        guardianName = data['guardianName']
        qualification = data['qualification']


        designation = data['designation']
        placeOfWork = data['placeOfWork']
        joiningDate = data['doj']
        empType = data['emp_type']


        mobile = data['mobile']
        corporateNumber = data['corporate_number']
        email = data['email']
        alternateNumber = data['alternate_number']


        ifscCode = data['ifscCode']
        bankName = data['bankName']
        branch = data['branch']
        accountNumber = data['accountNumber']
        esiNumber = data['esiNumber']
        pan = data['pan']
        adhaar = data['adhaar']
        vote = data['vote']
        passport = data['passport']
        belonging = data['belonging']
        

        gross = data['gross_salary']
        mobilebill = data['mobile_bill']
        basic = data['basic_salary']
        houseRent = data['house_rent']
        education = data['education_allow']
        medical = data['medical']
        other = data['other_allow']
        esiEmp = data['esi_emp']
        esiEmpr = data['esi_empr']
        esiTotal = data['esi_total']
        netSalary = data['net_salary']
        monthlyCtc = data['monthly_ctc']
        yearlyCtc = data['yearly_ctc']
        


        educationDoc = data["education_doc"] 
        experienceDoc = data["experience_doc"] 
        paySlipDoc = data["pay_slip_doc"] 
        resignationDoc = data["resignation_doc"] 
        photographDoc = data["photograph_doc"] 
        poiDoc = data["poi_doc"] 
        poaDoc = data["poa_doc"] 
################guardia_namedatabase
        print(dob, bankName, ifscCode, belonging,)
        emp = Emp(name=name, dob=dob, address=address,
                guardian_name=guardianName,qualification=qualification)
        emp.save()
        empid = Emp.objects.get(name = name)

        des = Designation.objects.get(name=designation)
        pow = Place.objects.get(name=placeOfWork)
        emp_office = EmpOffice(
            emp_type = empType,designation=des,place_of_work=pow,
            joining_Date = joiningDate, emp = empid
        )
        emp_office.save()
##############################corporte_mobile#########
        emp_contact =EmpContact(
            emp = empid, mobile = mobile, corporate_mobile = corporateNumber,
            email = email, alternate_mobile = alternateNumber
        )
        emp_contact.save()

        emp_bank = EmpBank(
            emp = empid, ifsc_code = ifscCode, bank_name = bankName,branch_name=branch,
            account_number = accountNumber, esi_number = esiNumber,pan = pan, adhaar = adhaar,
            vote = vote, passport = passport, belonging = belonging
        )
        emp_bank.save()

        emp_salary = EmpSalary(
            emp= empid,gross= gross,mobile_bill=mobilebill,basic=basic,house_rent = houseRent,education=education,
            medical=medical,other=other,esi_emp = esiEmp,esi_empr =esiEmpr,esi_total=esiTotal,
            net_salary= netSalary,monthly_ctc = monthlyCtc, yearly_ctc = yearlyCtc
        )
        emp_salary.save()

        emp_doc = EmpDoc(
            emp=empid,education=educationDoc,experience=experienceDoc,pay_slip = paySlipDoc,
            resignation = resignationDoc,photograph = photographDoc,poi = poiDoc,poa = poaDoc
        )
        emp_doc.save()

        # creating user and pass for emp with random passsof alphanum
        empname = Emp.objects.get(name = name)
        password = ''.join(random.choices(string.ascii_uppercase+string.digits,k=6))
        with open("emp_pass.txt", "a") as f:
            f.write(f"{empname} ::::::: {password}")
        myuser = User.objects.create_user(username=mobile,password=password)
        myuser.firstname = name
        myuser.save()
        print("saved")
        # print(emp,empid,emp.id)
        place = Place.objects.all()
        designation = Designation.objects.all()
        return redirect('show_emp')
    else:
        designation = Designation.objects.all()
        place = Place.objects.all()


    return render(request, "emp_crud/create_emp.html",{'designations':designation,'places':place,'EmpOffice':EmpOffice})


def show_emp(request):
    employees = Emp.objects.all()
    emp_contacts = EmpContact.objects.all()
    emp_office = EmpOffice.objects.all()

    for e,o,c in zip(employees,emp_contacts,emp_office):
        e.empContat = o
        e.empOffi = c

    for s in employees:
        print(s,s.empContat.mobile,e.empOffi.joining_Date)
        

    return render(request, "emp_crud/show_emp.html", {'employees':employees})





def update_emp(request,id):
    empid  = Emp.objects.get(pk=id)
    Empform = EmpForm(instance=empid)

    office = EmpOffice.objects.get(emp=empid)
    Empoffice = EmpOfficeForm(instance=office)

    contact = EmpContact.objects.get(emp=empid)
    Empcontact = EmpContactForm(instance=contact)

    bank = EmpBank.objects.get(emp=empid)
    Empbank = EmpBankForm(instance=bank)

    salary = EmpSalary.objects.get(emp=empid)
    Empsalary = EmpSalaryForm(instance=salary)

    doc = EmpDoc.objects.get(emp=empid)
    Empdoc = EmpDocForm(instance=doc)

    if request.method == "POST":
        Empform = EmpForm(request.POST,instance=empid)
        if Empform.is_valid():
            Empform.save()

        office = EmpOffice.objects.get(emp=empid)
        Empoffice = EmpOfficeForm(request.POST,instance=office)
        if Empoffice.is_valid():
            Empoffice.save()
        
        contact = EmpContact.objects.get(emp=empid)
        Empcontact = EmpContactForm(request.POST,instance=contact)
        if Empcontact.is_valid():
            Empcontact.save()

         
        bank = EmpBank.objects.get(emp=empid)
        Empbank = EmpBankForm(request.POST,instance=bank)
        if Empbank.is_valid():
            Empbank.save()

         
        salary = EmpSalary.objects.get(emp=empid)
        Empsalary = EmpSalaryForm(request.POST,instance=salary)
        if Empsalary.is_valid():
            Empsalary.save()

         
        doc = EmpDoc.objects.get(emp=empid)
        Empdoc = EmpDocForm(request.POST,instance=doc)
        if Empdoc.is_valid():
            Empdoc.save()
            return redirect("show_emp")


        
    return render(request,"emp_crud/update_emp.html",{'Empform':Empform,'Empoffice':Empoffice,
    'Empcontact':Empcontact,'Empbank':Empbank,'Empsalary':Empsalary,'Empdoc':Empdoc})








def delete_emp(request, id):
    emp = Emp.objects.get(pk=id)
    print(emp)
    return HttpResponse("got IT")
# employee crud views ends





def payslip(request):
    return render(request, "employee/payslip.html")


def attendance(request):
    attendances = Attendance.objects.all()
    return render(request, "attendance/attendance.html",{"attendances":attendances})



def reject_attendance(request,id):
    if Attendance.objects.get(pk=id):
        attendance = Attendance.objects.get(pk=id)
        if attendance.status == "A":
            attendance.status = "R"
            attendance.save()
            return redirect("attendance")
        if attendance.status == "R":
            return HttpResponse("Already Rejected")
        
    return HttpResponse("Not Present")

def makefull(request,id):
    if Attendance.objects.get(pk=id):
        attendance = Attendance.objects.get(pk=id)
        if attendance.half:
            attendance.half = False
            attendance.save()
            return redirect("attendance")
        else:
            return HttpResponse("its already Full")
    return HttpResponse("Not Present")

def makehalf(request,id):
    if Attendance.objects.get(pk=id):
        attendance = Attendance.objects.get(pk=id)
        if not attendance.half:
            attendance.half = True
            attendance.save()
            return redirect("attendance")
        else:
            return HttpResponse("its already Half")
    return HttpResponse("Not Present")




def custom_attendance(request):
    emps = Emp.objects.all()
    if request.method == "POST":
        empid = request.POST["emp_name"]
        empdate = request.POST["emp_date"]
        # emp = Emp.objects.get(name = empid)
        empid = Attendance.objects.get(emp = empid)
        print(empid,empid.date)
        empid.date = empdate
        empid.save()
        print("Custom Attendance Done!")
    else:
        emps = Emp.objects.all()
        

    return render(request,"attendance/custom_attendance.html",{"emps":emps})



def payslip(request):
    payslips = Payslip.objects.all()
    return render(request,"payslip/payslip.html",{'payslips':payslips})
    


def leave_approval(request):
    leaves = LeaveApproval.objects.all()
    return render(request, "leave_approval/leave_approval.html",{"leaves":leaves})



def leave_approval_approve(request,id):
    if LeaveApproval.objects.get(pk=id):
        leave = LeaveApproval.objects.get(pk=id)
        if  leave.status == "R" or leave.status=="P":
            leave.status = "A"
            leave.save()
            return redirect("leave_approval")
        else:
            return HttpResponse("its already Aprooved")
    return HttpResponse("Not Present")

    
    




def leave_approval_reject(request,id):
    if LeaveApproval.objects.get(pk=id):
        leave = LeaveApproval.objects.get(pk=id)
        if not leave.status == "R" or leave.status=="P":
            leave.status = "R"
            leave.save()
            return redirect("leave_approval")
        else:
            return HttpResponse("its already Rejected")
    return HttpResponse("Not Present")





def notice(request):
    notices = Notice.objects.all()
    return render(request,"notice/notice.html",{'notices':notices})


def notice_add(request):
    if request.method == "POST":
        form = NoticeForm(request.POST,request.FILES)
        if form.is_valid():
            # name = form.cleaned_data['name']
            # content = form.cleaned_data['notice_content']
            # attachment = form.cleaned_data['attachment']
            # notice= Notice(name=name,notice_content=content,attachment=attachment)
            # notice.save()
            form.save()
            return redirect("notice")
        else:
            HttpResponse("DATA input is not Valid")
    else:
        print("Got GET request from notice")
        form = NoticeForm()
    return render(request,"notice/notice_add.html",{"form":form})


def notice_edit(request,id):
    notice  = Notice.objects.get(pk=id)
    form = NoticeForm(instance=notice)
    if request.method == "POST":
        form = NoticeForm(request.POST,request.FILES,instance=notice)
        if form.is_valid():
            form.save()
            return redirect("notice")
        
    return render(request,"notice/notice_edit.html",{'form':form})


def notice_delete(request,id):
    notice  = Notice.objects.get(pk=id)
    notice.delete()
    return redirect('notice')



def travel(request):
    transports = TravelAllow.objects.all()
    return render(request,"travel/travel.html",{'transports':transports})





def travel_approve(request,id):
    if TravelAllow.objects.get(pk=id):
        leave = TravelAllow.objects.get(pk=id)
        if  leave.status == "R" or leave.status=="P":
            leave.status = "A"
            leave.save()
            return redirect("travel")
        else:
            return HttpResponse("its already Aprooved")
    return HttpResponse("Not Present")

    
    




def travel_reject(request,id):
    if TravelAllow.objects.get(pk=id):
        leave = TravelAllow.objects.get(pk=id)
        if not leave.status == "R" or leave.status=="P":
            leave.status = "R"
            leave.save()
            return redirect("travel")
        else:
            return HttpResponse("its already Rejected")
    return HttpResponse("Not Present")






def resignation(request):
    resignations = Resignation.objects.all()
    return render(request,"resignation/resignation.html",{'resignations':resignations})


##########################
def resignation_approve(request,id):
    if Resignation.objects.get(pk=id):
        resignation = Resignation.objects.get(pk=id)
        if resignation.status == "P" or resignation.status == "R":
            resignation.status = "A"
            resignation.save()
            return redirect("resignation")
        elif resignation.status == "A":
            return HttpResponse("Already Approved!!")
        else:
            return HttpResponse("Something wrong in aprooval")
  
    return HttpResponse("Not Present")


def resignation_reject(request,id):
    if Resignation.objects.get(pk=id):
        resignation = Resignation.objects.get(pk=id)
        if resignation.status == "P" or resignation.status == "A":
            resignation.status = "R"
            resignation.save()
            return redirect("resignation")
        elif resignation.status == "R":
            return HttpResponse("Already Rejected!!")
        else:
            return HttpResponse("Something wrong in aprooval")
  
    return HttpResponse("Not Present")
