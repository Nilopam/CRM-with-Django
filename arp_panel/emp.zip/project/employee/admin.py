from django.contrib import admin
from . models import *
# Register your models here.

my_models = [Emp,EmpOffice,EmpContact,EmpBank,EmpSalary,EmpDoc,Notice,
TravelAllow,Resignation,LeaveApproval,Attendance,Payslip]
admin.site.register(my_models)
