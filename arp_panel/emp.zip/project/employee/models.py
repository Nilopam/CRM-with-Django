from email.policy import default
from secrets import choice
from tokenize import ContStr
from django.db import models
from admin_panel.models import Designation,Place
# Create your models here.

class Emp(models.Model):

    name = models.CharField( max_length=50)
    address =models.CharField( max_length=50)
    dob = models.DateField()
    # empCode = models.CharField( max_length=50)
    guardian_name = models.CharField( max_length=50)
    
    qualification = models.CharField( max_length=50)

    def __str__(self):
        return self.name

    
class EmpOffice(models.Model):
    empTypes=(
        ('leader','Team Leader'),
        ('employee','Normal Employee')
    )
    emp = models.ForeignKey("Emp", on_delete=models.CASCADE)
    designation = models.ForeignKey(Designation,on_delete=models.CASCADE)
    place_of_work =models.ForeignKey(Place,on_delete=models.CASCADE)
    joining_Date = models.DateField()
    emp_type = models.CharField(choices=empTypes, max_length=50)
    
    def __str__(self):
        return self.place_of_work.name


class EmpContact(models.Model):
    emp = models.ForeignKey("Emp", on_delete=models.CASCADE)
    mobile = models.CharField( max_length=14)
    corporate_mobile = models.CharField( max_length=14)
    email = models.EmailField( max_length=254)
    alternate_mobile =models.CharField( max_length=14)
    
    def __str__(self):
        return self.mobile


class EmpBank(models.Model):
    emp = models.ForeignKey("Emp", on_delete=models.CASCADE)
    ifsc_code = models.CharField( max_length=50)
    bank_name = models.CharField( max_length=50)
    branch_name = models.CharField( max_length=50)
    account_number = models.CharField( max_length=50)
    esi_number = models.CharField( max_length=50)
    pan = models.CharField( max_length=50)
    adhaar = models.CharField( max_length=50)
    vote = models.CharField( max_length=50)
    passport = models.CharField( max_length=50)
    belonging = models.TextField( max_length=500)

    def __str__(self):
        return self.account_number



class EmpSalary(models.Model):
    emp = models.ForeignKey("Emp", on_delete=models.CASCADE)
    gross = models.CharField(max_length=50)
    mobile_bill = models.CharField(max_length=50)
    basic = models.CharField(max_length=50)
    house_rent = models.CharField(max_length=50)
    education = models.CharField(max_length=50)
    medical = models.CharField(max_length=50)
    other = models.CharField(max_length=50)
    esi_emp = models.CharField(max_length=50)
    esi_empr = models.CharField(max_length=50)
    esi_total = models.CharField(max_length=50)
    net_salary = models.CharField(max_length=50)
    monthly_ctc = models.CharField(max_length=50)
    yearly_ctc =models.CharField(max_length=50)

    def __str__(self):
        return self.gross



class EmpDoc(models.Model):
    emp = models.ForeignKey("Emp", on_delete=models.CASCADE)
    education = models.FileField( upload_to="uploads/education/", max_length=100)
    experience = models.FileField( upload_to="uploads/experience/", max_length=100)
    pay_slip = models.FileField( upload_to="uploads/pay_slip/", max_length=100)
    resignation = models.FileField( upload_to="uploads/resignation/", max_length=100)
    photograph = models.FileField( upload_to="uploads/photograph/", max_length=100)
    poi = models.FileField( upload_to="uploads/id_proof/", max_length=100)      #proof of identiy
    poa = models.FileField( upload_to="uploads/education/", max_length=100)     #proof of address

    def __str__(self):
        return self.emp.name












class TravelAllow(models.Model):

    Status = (
        ('A','Approve'),
        ('R','Reject'),
    )

    emp = models.ForeignKey("Emp", on_delete=models.CASCADE)
    date = models.DateField( auto_now=False, auto_now_add=False)
    from_where = models.CharField( max_length=50)
    destination = models.CharField( max_length=50)
    distance = models.CharField(max_length=50)
    expense = models.CharField(max_length=50)
    purpose = models.CharField(max_length=100)
    remarks = models.CharField(max_length=50)
    status = models.CharField(choices=Status,max_length=10,default="P")

    def __str__(self):
        return self.emp.name

    
class Notice(models.Model):

    name = models.CharField(max_length=50)
    notice_content = models.CharField(max_length=500)
    attachment = models.FileField(upload_to='Notice', max_length=100)
    created = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.name



class Resignation(models.Model):

    Status = (
        ('A','Approve'),
        ('R','Reject'),
        ('P','Pending'),
    )

    emp = models.ForeignKey("Emp", on_delete=models.CASCADE)
    reason = models.TextField()
    created_at = models.DateTimeField(auto_now=False, auto_now_add=True)
    experience_letter =models.CharField( max_length=50,blank=True) 
    release_letter = models.CharField( max_length=50,blank=True)
    status = models.CharField(choices=Status,default="P", max_length=1)
    def __str__(self):
        return self.emp.name

   

class LeaveApproval(models.Model):

    
    Category = (
        ('EL','EL'),
        ('CL','CL'),
    )
    Status = (
        ('A','Approve'),
        ('R','Reject'),
        ('P','Pending'),
    )
    emp = models.ForeignKey("Emp", on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now=True)
    from_date = models.DateField(auto_now=False, auto_now_add=False)
    to_date = models.DateField( auto_now=False, auto_now_add=False)
    category = models.CharField(choices=Category, max_length=50)
    reason = models.CharField( max_length=200)
    status = models.CharField(choices=Status, default="P",max_length=50)
    
 

    def __str__(self):
        return self.emp.name

    

class Attendance(models.Model):
    Status = (
        ('A','Approve'),
        ('R','Reject'),
        
    )
    emp = models.ForeignKey("Emp", on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now=False, auto_now_add=True)
    in_time = models.DateTimeField(auto_now=False, auto_now_add=False,blank=True,null=True)
    out_time = models.DateTimeField(auto_now=False, auto_now_add=False,blank=True,null=True)
    
    status = models.CharField(choices=Status,default="A", max_length=50)
    half = models.BooleanField(default=False)
    

    def __str__(self):
        return self.emp.name

    

    

class Payslip(models.Model):

    emp = models.ForeignKey("Emp", on_delete=models.CASCADE)
    salary = models.ForeignKey("EmpSalary", on_delete=models.CASCADE)
    status = models.BooleanField(default=False)
    time_stamp = models.DateTimeField(auto_now=False, auto_now_add=True)
    
    def __str__(self):
        return self.emp.name

    