from django.shortcuts import redirect, render
from employee.models import LeaveApproval,Emp,Resignation,TravelAllow
from employee.models import Attendance


# Create your views here.


def emp_dash(request):
    return render(request,"emp_dash.html")


def leave_application(request):
    emp = Emp.objects.get(name = request.user.first_name)
    leaves = LeaveApproval.objects.filter(emp = emp.id)
    if request.method == "POST":
        data = request.POST
        from_date = data['from_date']
        to_date = data['to_date']
        categor = data['category']
        reason = data['reason']
        empid = Emp.objects.get(id= emp.id)

        obj = LeaveApproval(emp = empid,from_date=from_date,to_date=to_date
        ,category = categor ,reason=reason)

        obj.save()
        return redirect("leave_application")





    context = {
        "leaves" : leaves,
        'category' : LeaveApproval.Category
    }
    return render(request,"leave_application.html",context)




def apply_resignation(request):

    empid = Emp.objects.get(name = request.user.first_name)
    resignations = Resignation.objects.filter(emp = empid)
    if request.method == "POST":
        data = request.POST
        reason = data['reason']
        empid = Emp.objects.get(id= empid.id)

        obj = Resignation(emp = empid,reason = reason)
        obj.save()
        return redirect("apply_resignation")

    context = {
        "resignations":resignations
    }
    return render(request,"apply_resignation.html",context)




def apply_travel_allow(request):
    empid = Emp.objects.get(name= request.user.first_name)
    if request.method == "POST":
        print("Got POST request from apply_travel_allow")
        data = request.POST
        from_where = data['from_where']
        destination = data['destination']
        date = data['date']
        expense = data['expense']
        distance = data['distance']
        purpose = data['purpose']
        remarks = data['remarks']
        empid = Emp.objects.get(id= empid.id)
        obj = TravelAllow(emp = empid,date=date,from_where=from_where,
        destination=destination,distance=distance,expense=expense,purpose=purpose,
        remarks=remarks)

        obj.save()
        print(f"{empid} applied TA")
        return redirect("apply_travel_allow")
    
    tas = TravelAllow.objects.filter(emp = empid)

    context = {
        "tas":tas
    }
    return render(request,"apply_travel_allow.html",context)




def emp_attendance(request):

    emp = Emp.objects.get(name = request.user.first_name)
    
    attendances = Attendance.objects.filter(emp = emp.id)

    context = {
        "attendances" :attendances
    }

    return render(request,"emp_attendance.html",context)