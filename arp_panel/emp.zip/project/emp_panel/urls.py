from django.urls import path
from . import views

urlpatterns = [

    
    path("emp_dash",views.emp_dash,name="emp_dash"),
    path("leave_application",views.leave_application,name="leave_application"),

    path("apply_resignation",views.apply_resignation,name="apply_resignation"),

    path("apply_travel_allow",views.apply_travel_allow,name="apply_travel_allow"),

    path("emp_attendance",views.emp_attendance,name="emp_attendance"),

    
  
]