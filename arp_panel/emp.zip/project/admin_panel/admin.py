from django.contrib import admin
from .models import *
# Register your models here.

myModels = [Designation,Place,Holiday,Category,BankAccount,ArpParty,PrpParty,
ExpenseItem,ExpenseCategory,ArpProduct,ArpService,PrpService]
admin.site.register(myModels)