from django.urls import path
from . import views

urlpatterns = [
    path("add_daily_work",views.add_daily_work,name="add_daily_work"),
  
]