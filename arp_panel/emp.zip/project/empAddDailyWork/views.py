from django.shortcuts import redirect, render
from dailyreport.models import *
from django.contrib.auth.models import User
from employee.models import Emp
from admin_panel.models import ArpParty


# Create your views here.
def add_daily_work(request):
    
    
    print(request.user.first_name)
    emp = Emp.objects.get(name = request.user.first_name)
    print(emp.id)
    if request.method == "POST":
        data = request.POST
        party = ArpParty.objects.get(id = data['party'])

        empid = Emp.objects.get(id = emp.id)
        work_detail = data['work_detail']

        
        obj = DailyReport(emp= empid,party=party,work_detail=work_detail)
        obj.save()
        return redirect("add_daily_work")


    context = {
        "reports" : DailyReport.objects.filter(emp = emp.id),
        "partys" : ArpParty.objects.all()
    }
    return render(request,"add_daily_work.html",context)