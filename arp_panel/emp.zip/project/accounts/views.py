from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from employee.models import Emp
# Create your views here.



def loginn(request):
    if request.method == "POST":
        username = request.POST['name']
        password = request.POST['password']
        user = authenticate(username = username,password = password)
        if user is not None:
            login(request,user)
            return redirect("emp_dash")
        else:
            return HttpResponse("Wrong Credentials..")
    return render(request,"login.html")



